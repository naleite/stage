/***************************************************************
Nom du fichier: /.../detection_binomial_zone.c
Descriptif    :	Cr�ation d'une routine de test monte carlo de 
                perfs en detection avec lumi�res sous poissonienne 
                modele binomial
                But: d�tecter un objet sur un fond
Auteur        : J.Fade .
Date          : 29/02/08 
Nom du coordinateur informatique: F Galland
****************************************************************/


//#include "lib_std.h"
#include <time.h>
# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <getopt.h>
# include "librairie.h"
# include <sys/timeb.h>

//#include "lib_math.h"
//#include "lib_phyti.h"
//# include "math_vect_gcc.h"
//# include "im_utils_gcc.h"
//# include "util_srf_gcc.h"
//# include "im_manip_gcc.h"
//# include "math_vect_2_gcc.h"

//# include "lib_quantique.h"


void calcul_histo(double *vecteur, int size, double min, double max, int pt_nb_bin, double *histo)
{
  int k,j;
  double delta=0;
  
  j=0;

  delta = (double) (max -min) / pt_nb_bin;
  /*  fprintf(stderr,"\n  %g ",delta);
      fprintf(stderr,"\n %d ",pt_nb_bin);fprintf(stderr,"\n %g ",min);fprintf(stderr,"\n %g ",max); */

  for (k=0;k< size;k++)
    {
      vecteur[k] =( vecteur[k] - min)/delta; 
      //      fprintf(stderr,"\n %g",vecteur[k]);
    }

  for (k=0;k< size;k++)
    {
      j= (int) vecteur[k];
      histo[j] += 1;
    }
  
  
}



void  calcul_Pd_Pfa(int nb_niv, double *tab_P, double *tab_Q, int nb_pts)
{
  int k=0;

  /* Normalisation des vecteurs pour avoir Pfa et Pd max de 1 */
  for(k=0;k<nb_niv;k++) 
     { 
       tab_P[k]  =  tab_P[k]/nb_pts; 
       tab_Q[k]  =  tab_Q[k]/nb_pts; 
       //      fprintf(stderr,"(%f) %f", tab_P[k], tab_Q[k]); 
     } 
/* Construction des courbes Pf Pfa */ 
  
   for(k=2;k<nb_niv+1;k++) 
     { 
       tab_P[nb_niv - k]  +=  tab_P[nb_niv+1-k]; 
       tab_Q[nb_niv - k]  +=  tab_Q[nb_niv+1-k]; 
       //      fprintf(stderr,"(%f) %f", tab_P[k], tab_Q[k]); 
     } 

}


void histo_zones(double *crit, int nb_niv,double dx,double n_min, int reals, 
		 double *hist_abs, double *hist_val_cible, double *hist_val_fond)
{
  
  int	  i=0;
  int     k=0;
  int     j=0;
  double  yk=0.0;
  double  n_max=0.0;
  int     count=0;
  
/*   FILE *donnees;  */
/*   FILE *donn;     */
/*   FILE *donn;     */
  
/*   // Ouverture du fichier de donn�es � �crire  */
/*   //========================================   */
/*   donnees= fopen("donnees.dat","w");           */
/*   donn   = fopen("donn.dat","w");              */
  
  n_max=(nb_niv-1)*dx + n_min ;
  //  fprintf(stderr,"test: %f \n",n_max);
  // fprintf(stderr,"%d ",nb_niv);
  
  
  /* Initialisation tableaux histogramme */
  for(k=0;k<nb_niv;k++)
    {
      hist_val_cible[k]=0.0;
      hist_abs[k]=n_min+(k+0.5)*dx;  
      //      fprintf(stderr,"test: %f \n",hist_abs[k]);

    }
  
  /* Debut boucle calcul histogramme PARTIE CIBLE*/
  j=0;
  for(i=0;i<reals;i++)
    { 
      if(crit[i]>=n_max) {j=nb_niv-1;}
      else
	{
	  yk=crit[i];
	  j=(int)floor((double)((yk-n_min)/dx));
	}               
      
      if((j>=0)&&(j<=nb_niv-1)) { hist_val_cible[j]++; count++;}
    }/*end for i*/

  
  j=0;yk=0.0;i=0;

  /* Debut boucle calcul histogramme PARTIE FOND*/
  for (i=reals;i<2*reals;i++)
    {
      if(crit[i]>=n_max) { j=nb_niv-1;}
      else
	{
	  yk=crit[i];
	  //	  fprintf(donn,"%e ",yk);
	  if (crit[i]-n_min<0.0){fprintf(stderr,"(%d) %g ",i, yk);}
	  j=(int)floor((double)((yk-n_min)/dx));
	}               
      
      if((j>=0)&&(j<=nb_niv-1)) { hist_val_fond[j]++; count++;}
    }/*end for i*/

  /* Renormalisation */  
  for(k=0;k<nb_niv;k++)
    {
      hist_val_cible[k] =  hist_val_cible[k]/(reals);
      hist_val_fond[k]  =  hist_val_fond[k]/(reals);
    }
  
  /* Construction des courbes Pf Pfa */
  for(k=1;k<nb_niv;k++)
    {
      hist_val_cible[k] +=  hist_val_cible[k-1];
      hist_val_fond[k]  +=  hist_val_fond[k-1];
    }

  //Verif 
  //  fprintf(stderr,"\n  %d \n", count);
  if ( count < 2*reals) 
    {
      fprintf(stderr,"\n ATTENTION : MAUVAIS CHOIX DE PARAMETRES DE L HISTOGRAMME %d \n", count);
    }
  
/*   for(k=0;k<nb_niv;k++) */
/*     {  */
/*       fprintf(donn,"%g ",hist_val_fond[k]); */
/*       fprintf(donnees,"%g ",hist_abs[k]); */
/*       fprintf(don,"%g ",hist_val_cible[k]);    */
/*     } */
/*   fclose(donnees);  */
/*   fclose(donn); */
/*   fclose(donn); */
}         /*end histo_zones*/    




/******
calcule_critere_GLRT(int  taille, int reals,double **champ, int taille_cible)
			
******/
/*=========================================================================*/
/* entree : taille            : Taille d'un �chantillon                    */
/*          reals        : Nombre de r�alisations                          */
/*          champ        : image a cr�er                                   */
/*          taille_cible : Taille de la zon cible                          */
/* sortie : crit         : vecteur des crit�res pour chaque r�als          */
/*=========================================================================*/
/* auteur : J.FADE                                                         */
/* date   : 29/02/08                                                       */
/* Coordinateur : F.Galland                                                */
/*=========================================================================*/
void calcule_critere_GLRT(int  taille, int reals, double **champ, int taille_cible, double *critere, int flag_cible)
{
  int i,j;
  double sum_c=0.0;
  double sum_f=0.0;
  double tmp;
 
  // Test partie de l'image cible ou fond
  if (flag_cible==1){ flag_cible = 0; }
  else { flag_cible = reals; }

  for (i=0;i<reals;i++)           // boucle sur les lignes de realisations
    {
      sum_c=0.0;
      sum_f=0.0;
      for (j=0;j<taille_cible;j++)
	{
	  sum_c += champ[i+flag_cible][j];
	}
      
      for (j=taille_cible;j<taille;j++)
	{
	  sum_f += champ[i+flag_cible][j];
	}
      
      tmp = 
	  sum_c  * log( sum_c / (double) taille_cible)
	+ sum_f  * log( sum_f / (double) (taille-taille_cible))
 	- (sum_c+sum_f) * log( (sum_c+sum_f)/ (double) taille);
      
      // force positif
      if (tmp > 0.0)
	critere[i] = tmp ;
      else
	critere[i] = 0.0 ;
    } 
} // End of calcule_critere_GLRT




/******
calcule_critere_LRTpoi(int  taille, int reals,double **champ, int taille_cible)
			
******/
/*=========================================================================*/
/* entree : taille            : Taille d'un �chantillon                    */
/*          reals        : Nombre de r�alisations                          */
/*          champ        : image a cr�er                                   */
/*          taille_cible : Taille de la zon cible                          */
/* sortie : crit         : vecteur des crit�res pour chaque r�als          */
/*=========================================================================*/
/* auteur : J.FADE                                                         */
/* date   : 29/02/08                                                       */
/* Coordinateur : F.Galland                                                */
/*=========================================================================*/
void calcule_critere_LRTpoi(int  taille, int reals, double **champ, int taille_cible, double *critere, int flag_cible,
			    double moy_cible, double moy_fond)
{
  int i,j;
  double sum_c=0.0;
  double tmp;
 
  
  fprintf(stderr,"(%f) %f",moy_cible,moy_fond);
  // Test partie de l'image cible ou fond
  if (flag_cible==1){ flag_cible = 0; }
  else { flag_cible = reals; }

  for (i=0;i<reals;i++)           // boucle sur les lignes de realisations
    {
      sum_c=0.0;
      for (j=0;j<taille_cible;j++)
	{
	  sum_c += champ[i+flag_cible][j];
	}
      
      tmp = 
	(double) - taille_cible *(  moy_cible -moy_fond )
	+ (log( moy_cible) - log( moy_fond) )* sum_c;
      
      // force positif
      if (tmp > 0.0)
	critere[i] = tmp ;
      else
	critere[i] = tmp;//0.0 ;
    } 
for (i=0;i<reals;i++)    
{  critere[i]=champ[i+flag_cible][1]; 
}

} // End of calcule_critere_LRTpoi



/******
genere_echantillons(int  taille, int reals,double **champ, int taille_cible,
			 unsigned int N_cible, unsigned int N_fond, double fano_fond);
******/
/*=========================================================================*/
/* entree : taille            : Taille d'un �chantillon                    */
/*          reals        : Nombre de r�alisations                          */
/*          champ        : image a cr�er                                   */
/*          taille_cible : Taille de la zon cible                          */
/*          moy_cible    : Moyenne de la cible                             */
/*          fano_init    : Fano de la cible                                */
/*          moy_fond     : Moyenne du fond                                 */
/*          fano_fond    : Fano du fond                                    */
/* sortie : champ        : image cr��e eclairement gaussien                */
/*=========================================================================*/
/* auteur : J.FADE                                                         */
/* date   : 29/02/08                                                       */
/* Coordinateur : F.Galland                                                */
/*=========================================================================*/
void genere_echantillons_detection(int taille, int reals, double **champ,  int taille_cible, int  N_cible, double Fano_init, double Fano_fond)
{

  int i,j;
  
  //fprintf(stderr,"\n%f %d ",(double) (1.0-Fano_init)*N_cible , N_cible);
  if (N_cible == 0)    // Gestion du cas Poissonien 
    { 
      for(j=0;j<taille_cible ;j++)  // Construction image avec cible
	for(i=0;i<reals;i++)          // Construction cible
	  { 
	    champ[i][j]=tirage_poisson( Fano_init);
	    
	  }  
      for(j=taille_cible;j<taille ;j++)   // Construction fond
	for(i=0;i<reals;i++)
	  {
	    champ[i][j]=tirage_poisson(Fano_fond);  
	    champ[i+reals][j]=champ[i][j]; // Recopie les �chantillons fond
	  }
      for(j=0;j<taille_cible;j++)          // Construction image sans cible
	for(i=0;i<reals;i++)
	  {
	    champ[i+reals][j]=tirage_poisson( Fano_fond);
	  }
    }
  else                        // Cas du bruit sous poisosn
    {                     
      for(j=0;j<taille_cible ;j++)  // Construction image avec cible
	for(i=0;i<reals;i++)  // Construction cible
	  { 
	    champ[i][j]=tirage_binomial( (1.0-Fano_init) , N_cible);
	  }  
      for(j=taille_cible;j<taille ;j++)// Construction fond
	for(i=0;i<reals;i++)
	  {
	    champ[i][j]=tirage_binomial( (1.0-Fano_fond) , N_cible); 
	    champ[i+reals][j]=champ[i][j]; // Recopie les �chantillons fond
	  }
      for(j=0;j<taille_cible;j++) // Construction image sans cible
	for(i=0;i<reals;i++)
	  {
	    champ[i+reals][j]=tirage_binomial( (1.0-Fano_fond) , N_cible);
	  }
    }
} /* end of genere_echantillons */






/*********** Caracteristiques de la fonction **********************/
/*Cette fonction contient le texte de l'aide en ligne.		*/
/*Elle apparait a l'ecran lorsqu (pas encore valide).'on tape : detection_binomial -m   */
/***************************************************************/
/*
  void usage(fp_out,argv)
  FILE *fp_out;
  char **argv;
*/
void usage(FILE *fp_out, char **argv)
{
  fprintf(fp_out,"\n USAGE :%s",argv[0]);
  fprintf(fp_out,"\n           -N 'Taille ech' : dimension [paire] (X) de l'�chantillon � cr�er");
  fprintf(fp_out,"\n           -R 'Reals' : dimension [paire] (Y) du nb de realisations");
  fprintf(fp_out,"\n           -C 'Taille Cible' : dimension de la cible � consid�rer");
  fprintf(fp_out,"\n           -m 'moy cible' : valeur moyenne du nb photons / pixel cible");
  fprintf(fp_out,"\n           -F 'Fano 0' : facteur de Fano de la lux sous poi de la cible");
  fprintf(fp_out,"\n           -r 'ref coeff' : coefficient de reflexion m_back=r * m_cible ");
  fprintf(fp_out,"\n           -B Nombre de bins utilises pour evaluer les histogrammes ");
  fprintf(fp_out,"\n           -i initialisation de la graine (g�n�ration nbs al�atoires) ");
  fprintf(fp_out,"\n           -h fournit cette page de manuel");
  fprintf(fp_out,"\n           -S fournit le nom du fichier de sortie (pd/pfa)\n");
  fprintf(fp_out,"\n Cr�e une image N*R contenant R realisations de tirages sous poissoniens");
  fprintf(fp_out,"\n d'intensit� comportant C pixels cible et N-C pixels de fond");
  fprintf(fp_out,"\n Par defaut N=R=256, Fano = 1 (poisson) et m egale a 10.");
  fprintf(fp_out,"\n Par d�faut, la cible fait N/2 ");
  fprintf(fp_out,"\n Image de sortie au format srf ou bin");
  fprintf(fp_out,"\n     La sortie se fait toujours sur la sortie standard \n");
  fprintf(fp_out,"\n Exemple : \n ");
  exit(0);
  
} 

/******************caracteristiques de la fonction **********************/
/*nom de la fonction : Verif_entrees					*/
/*entrees            : argc,argv					*/
/*sorties            : nom_ima,format					*/
/*appel              :							*/
/*remarques          : Verification des options et recup parametres	*/
/*        recup parametres de la ligne de commande			*/
/************************************************************************/

void Verif_entrees(int argc,char **argv,
		   int *taille,int *reals, int *taille_cible,
		   double *moy_cible, double  *fano_init,  
		   double *abs_coef, int *init, int *pt_nb_bin,
		   char **nom_sortie,
		   int *flag_taille,int *flag_reals, int *flag_taille_cible,
		    int *flag_moy_cible, int *flag_abs_coef, int *flag_fano_init,int *flag_bin)

{
  
  int c;		/* index into parent argv vector */
  extern char *optarg;
  char *chaine="N:R:C:m:F:r:B:S:ih";
  
  nom_sortie[0]=NULL;
  *taille = 0;
  *reals = 0;
  *taille_cible = 0;
  *moy_cible = 0.0;
  *fano_init = 0.0 ;
  *abs_coef= 0.0;
  *init=0;
  *flag_taille=0;
  *flag_reals=0; 
  *flag_moy_cible=0;
  *flag_taille_cible=0;
  *flag_abs_coef=0;
  *flag_bin=0;
  *flag_fano_init=0;
  
  while ((c = getopt(argc, argv, chaine)) != EOF)
     {
     switch (c) 
       { 
       case 'N': *taille=atoi(optarg);*flag_taille=1;break;
       case 'R': *reals=atoi(optarg);*flag_reals=1;break;
       case 'C': *taille_cible=atoi(optarg);*flag_taille_cible=1;break;
       case 'm': *moy_cible=atof(optarg);*flag_moy_cible=1;break;
       case 'F': *fano_init=atof(optarg);*flag_fano_init=1;break;
       case 'B': *pt_nb_bin=atoi(optarg);*flag_bin=1;break;
       case 'r': *abs_coef=atof(optarg);*flag_abs_coef=1;break;
       case 'S': nom_sortie[0]=optarg;break;
       case 'i': *init=1; break;	 
       case 'h': usage(stderr,argv);break;
       default : usage(stderr,argv);break;
       }
     }
}


/*****************************************************************/
/********************    PGM PRINCIPAL   *************************/
/*****************************************************************/


int main(int argc,char **argv)
{
  
	
  int      taille, reals, taille_cible;           /* Taille Ech, nb Realisation, taille cible */
  double   moy_cible, fano_init;                  /* Moyenne de la cible, Facteur de Fano initial cible */
  double   moy_fond, fano_fond;                   /* Moyenne du fond, Facteur de Fano fond */ 
  int      N_cible;     
  double   abs_coef;                              /* Coeff d'absorption entre cible et fond */
  double   alpha;
  int      flag_taille, flag_reals, flag_abs_coef;
  int      flag_taille_cible, flag_fano_init,flag_moy_cible,test,flag_bin;
  int      pt_nb_bin;

  double   **champ=NULL;                          /*image de sortie*/
  double   *crit_c=NULL,*crit_f=NULL;             /* vecteur des criteres de taille Reals */
  /*double   *hist_abs=NULL;
  double   *hist_val_cible=NULL;                  // vecteurs des histogrammes
  double   *hist_val_fond=NULL;*/

  double   *tab_X=NULL,*tab_P=NULL,*tab_Q=NULL;//,*crit=NULL;

  int       init,k=0;                                 // indice pour l'initialisation ou non de la graine al�atoire.
  struct    timeb temps;	                  // necessaire pour initialiser ou non la graine
  char      *nom_sortie[1];


  // VErif 
  FILE      *sav_crit_c,*sav_crit_f;

  sav_crit_c= fopen("crit_c.dat","w");
  sav_crit_f= fopen("crit_f.dat","w");

  /*** Lecture des parametres ***/
  
  Verif_entrees(argc,argv,
		&taille, &reals, &taille_cible,  
		&moy_cible, &fano_init, 
		&abs_coef, &init, &pt_nb_bin, nom_sortie,
		&flag_taille,&flag_reals, &flag_taille_cible, 
		&flag_moy_cible, &flag_abs_coef,&flag_fano_init,&flag_bin);



  // initialisation du generateur de nombres aleatoires du c */
  //==============================
  if (init != 0)
    {
      time(&(temps.time));
      srand48(temps.time);
    }

  // Quelques v�rification d'usage...

  if (flag_taille==0) taille=256;
  if (flag_reals==0) reals=256;
  
  if (flag_moy_cible==0) 
    {
      fprintf(stderr,"\n Attention!!!, vous n'avez pas entre de valeur pour la moyenne de la cible!\n");
      fprintf(stderr," Fix� par defaut a m=10 \n");
      moy_cible=10.0;
    }
  if (flag_taille_cible==0) 
    {
      fprintf(stderr,"\n Attention!!!, vous n'avez pas entre de valeur pour la taille de la cible !\n");
      fprintf(stderr," Fix� par defaut � N/2 \n");
      taille_cible=taille/2;
    }
  if (flag_fano_init==0) 
    {
      fprintf(stderr,"\n Attention!!!, vous n'avez pas entre de valeur pour le facteur de fano initial !\n");
      fprintf(stderr," Fix� par defaut au cas Poisson F0=1.0 \n");
      fano_init=1.0;
    }
  if (flag_abs_coef==0) 
    {
      fprintf(stderr,"\n Attention!!!, vous n'avez pas entre de valeur pour le coefficient d'absorption !\n");
      exit(0);
    }
  if (fano_init<0.0||fano_init>1.0 || abs_coef < 0 || abs_coef > 1 || taille_cible > taille ){
    fprintf(stderr,"\n ERREUR(S), Valeur(s) non admissible(s) du (des) param�tre(s) ! \n\n");
    exit(0);
  } 
  if (flag_bin==0) 
    {
      fprintf(stderr,"\n Attention!!!, nb de bins de l'histogramme non entre => par defaut 25 \n");
      pt_nb_bin=25;
    }



  /* Calcul des param�tres */
  //  fprintf(stderr,"%g\n",moy_cible/fano_init);
  
  if (fano_init<=0.999)  //Cas binomial
    {
      N_cible = (int) d_round( moy_cible/(1.0-fano_init));  
      fprintf(stderr,"Choix stat binomiale : \n\n");
      fprintf(stderr,"Valeur du param N de la cible %d",N_cible);
      moy_cible = (double) N_cible * (1.0-fano_init); 
      moy_fond  = abs_coef*moy_cible;
      alpha     = abs_coef+ ( 1.0 - abs_coef ) / fano_init;   
      fano_fond = alpha * fano_init;
      
      fprintf(stderr,"\n Moy_cible corrige=%g",moy_cible);
      fprintf(stderr,"\n Fano_cible=%g ",fano_init);
      fprintf(stderr,"\n Moy_fond=%g",moy_fond);
      fprintf(stderr,"\n Fano_fond=%g ",fano_fond);
    }
  else   // Cas stat poissonienne
    {
      N_cible = 0; fano_init=moy_cible;  
      moy_fond=abs_coef * moy_cible; fano_fond= moy_fond;
      fprintf(stderr,"Choix stat poissonienne : \n\n");
      fprintf(stderr,"\n Moy_cible=%g",moy_cible);
      fprintf(stderr,"\n Moy_fond=%g\n\n",moy_fond);
    }
  
  
  /* Allocation des tableaux et images */
  champ          =d_alloue_2d(2*reals,taille);

  //  hist_abs       =d_alloue_1d(pt_nb_bin); 
  // hist_val_cible =d_alloue_1d(pt_nb_bin);  
  // hist_val_fond  =d_alloue_1d(pt_nb_bin);
  // crit           =d_alloue_1d(2*reals);  
  crit_c           =d_alloue_1d(reals);      
  crit_f           =d_alloue_1d(reals); 



  /* Fabrication de l'image des �chantillons/r�alisations  */
  genere_echantillons_detection(taille,reals,champ,taille_cible,
				N_cible,fano_init,fano_fond); 

  /* Calcul du crit�re*/
  // calcule_critere_GLRT(taille,reals,champ,taille_cible,crit_c,1); // Dans la partie avec cible
  // calcule_critere_GLRT(taille,reals,champ,taille_cible,crit_f,0); // Dans la partie sans cible
    calcule_critere_LRTpoi(taille,reals,champ,taille_cible,crit_c,1,moy_cible,moy_fond); // Dans la partie avec cible
    calcule_critere_LRTpoi(taille,reals,champ,taille_cible,crit_f,0,moy_cible,moy_fond); // Dans la partie sans cible

  // Choix nb bins et allocation tabs pour histos
  pt_nb_bin=(int) d_max( d_max_1d(crit_c,reals), d_max_1d(crit_f,reals) ) +1;//Choix du nb bins pour l'histo
  fprintf(stderr,"\n  Choix nb bins pour histogrammes %d ",pt_nb_bin);
  tab_P            =d_alloue_1d(pt_nb_bin);
  tab_Q            =d_alloue_1d(pt_nb_bin);  
  tab_X            =d_alloue_1d(pt_nb_bin+1);


  /* Calcul des histogrammes et courbe COR */

  for (test=0;test<reals;test++)
    {
      fprintf(sav_crit_c,"%f ",crit_c[test]);      
      fprintf(sav_crit_f,"%f ",crit_f[test]);
    }
  // verif
  fclose(sav_crit_c);fclose(sav_crit_f);
    
  // Cr�ation abscisse histogrammes
  for (k=0; k<pt_nb_bin; k++)
    {
      tab_X[k]=(double) k - 0.5;
    }
  tab_X[pt_nb_bin]=(double) pt_nb_bin - 0.5;
  
  //Calcul de l'histogramme des tests Pi pour l'echantillon 1 avec cible
  calcul_histo( crit_c, reals, (double) 0., (double) pt_nb_bin, pt_nb_bin, tab_P);

  //Calcul de l'histogramme des tests Pi pour l'echantillon 1 sans cible
  calcul_histo( crit_f, reals, (double) 0., (double) pt_nb_bin, pt_nb_bin, tab_Q);

  // Calcul des courbes Pd/Pfa � partir des histos
  calcul_Pd_Pfa(pt_nb_bin, tab_P,tab_Q,reals);

  /* Enregistrement des vecteurs Pd/Pfa */
  if ( nom_sortie[0]!= NULL )
    {
      //saveVec2oct(hist_abs,pt_nb_bin ,"Absc",nom_sortie[0],1); 
      //saveVec2oct(hist_val_cible,pt_nb_bin ,"Pd",nom_sortie[0],0); 
      //saveVec2oct(hist_val_fond ,pt_nb_bin ,"Pfa",nom_sortie[0],0);  
      saveVec2oct(tab_X,pt_nb_bin,"Abs",nom_sortie[0],1);
      saveVec2oct(tab_P,pt_nb_bin,"Pd",nom_sortie[0],0);
      saveVec2oct(tab_Q,pt_nb_bin,"Pfa",nom_sortie[0],0); 
      saveMat2oct(champ, taille , 2*reals,"img",nom_sortie[0],0);
    }
  else
    { fprintf(stderr,"\n ! Pas d'enregistrement des resultats !\n");  
    }

  fprintf(stderr,"\n\n PROGRAMME EN CHANTIER\n\n");
  
  


  
  /* Desallocation  */
  d_efface_2d(2*reals,taille,champ);   
  free(crit_c);           free(crit_f);   
  free(tab_Q);           // free(crit);
  free(tab_P);           // free(hist_abs);
  //  free(hist_val_cible);   free(hist_val_fond);
  free(tab_X);
  
  return 0;
}
