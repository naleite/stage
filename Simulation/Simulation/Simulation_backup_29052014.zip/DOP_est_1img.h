//
//  DOP_est_1img.h
//  Simulation
//
//  Created by NALEITE on 14-5-16.
//
//

#ifndef Simulation_DOP_est_1img_h
#define Simulation_DOP_est_1img_h

extern int DOP_est_1img(int largeur, int hauteur, int ordre, double Imoyco, double DOP, int reals, char *nom_fich);

#endif
