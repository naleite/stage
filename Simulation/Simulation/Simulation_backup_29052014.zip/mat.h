

int mathieu(int age);
