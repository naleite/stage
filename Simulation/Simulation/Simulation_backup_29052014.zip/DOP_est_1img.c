/********************************************************************************/
/* Date:	02.10.07					*/
/* Written by:	Julien Fade					*/
/* Description:	Simulation MC pour validation méthode d'estimation du degré de polarisation à partir*/
/* d'une unique image de speckle.                               */
/*								*/
/****************************************************************/


# include <time.h>
# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <getopt.h>
//# include "librairie.h"
# include <sys/timeb.h>
# include <sys/timeb.h>
#include "utils_fade.h"
#include "utils_tirage.h"
//#include "lib_std.h"
//#include <stdio.h>
//#include <stdlib.h>
//#include <math.h>
//#include <sys/types.h>
//#include <sys/timeb.h>
//#include <sys/time.h>

//#include "lib_phyti.h"
//#include "/home/fade/Progs/Progs_C/Sources_C/lib_quantique.h"
//#include "math_vect_gcc.h"
//#include "lib_Modif_image_gcc.h"
//#include "lib_srf_gcc.h"


/****************************************************************/
/******************    FONCTIONS  d'E/S   ***********************/
/****************************************************************/

void usage(FILE *fp_out,char **argv)
{
    fprintf(fp_out,"\n ==============================================================");
    fprintf(fp_out,"\n USAGE:DOP_est_1img : lancement d'une expérience d'estimation");
    fprintf(fp_out,"\n de degré de polarisation à partir d'une unique image de speckle");
    fprintf(fp_out,"\n l'image creee est au format BIN");
    fprintf(fp_out,"\n ==============================================================");
    fprintf(fp_out,"\n  options valables :");
    fprintf(fp_out,"\n \t-o ordre de la loi gamma marginale  (def = 1)");
    fprintf(fp_out,"\n \t-I moyenne de l'intensité totale de la lumière simulée   ");
    fprintf(fp_out,"\n \t-P valeur VRAIE du degré de polarisation de la lumière");
    fprintf(fp_out,"\n t TAILLE DE L'ECHANTILLON D'ESTIMATION N=x*y");
    fprintf(fp_out,"\n \t-x largeur de l'image échantillon generee (def =50)");
    fprintf(fp_out,"\n \t-y hauteur de l'image échantillon generee (def =50)");
    fprintf(fp_out,"\n \t-R nombre de réalisations à considérer dans l'exp Monte Carlo");
    fprintf(fp_out,"\n \t-i pour initialiser la graine ");
    fprintf(fp_out,"\n \t-s nom du fichier de sortie (data pour octave)");
    fprintf(fp_out,"\n \t-m  fournit cette page de manuel");
    fprintf(fp_out,"\n ==============================================================");
    fprintf(fp_out,"\n Ex : DOP_est_1img -o 1 -P 0.33  -s sav_oct.dat -I 100 -x 50 -y 50 -R 2000 -i > resultats.dat \n");
    fprintf(fp_out,"\n ==============================================================");
    fprintf(fp_out,"\n ATTENTION:");
    fprintf(fp_out,"\n 1. ce programme n'est valable que pour des ordres entiers");
    fprintf(fp_out,"\n 2. si il est lance 2 fois en moins d'une seconde, il genere 2fois la meme sequence");
    fprintf(fp_out,"\n ");
    fprintf(fp_out,"\n ");
    exit(0);
}

void Verif_entrees(int argc,char **argv,char **nom_fich, int *ordre,double *moyenne, double *DOP, int *hauteur,int *largeur,int *reals,int *init)
{
    int             c;
    extern char     *optarg;
    char            *chaine="o:I:P:s:x:y:R:im"; /* Chaine de char des options choisies*/
    
    
    /*----------------*/
    /* Initialisation */
    /*----------------*/
    *ordre=1;
    nom_fich[0]=NULL;
    *DOP=-1.;
    *moyenne=0.;
    *hauteur=20;  //  saveVec2oct(double *input, int dim_Ligne, char* name_var, char* name_file, int 1)
    *largeur=20;
    *reals=0;
    *init=0;
    
    while ((c = getopt(argc, argv, chaine)) != EOF)
    {
        switch (c)
        {
            case 'o': *ordre=atoi(optarg);break ;
            case 'I': *moyenne=atof(optarg);break ;
            case 'P': *DOP=atof(optarg);break;
            case 'y': *hauteur=atoi(optarg);break ;
            case 'x': *largeur=atoi(optarg);break ;
            case 'i': *init=1;break ;
            case 'R': *reals=atoi(optarg);break;
            case 's': nom_fich[0]=optarg;break;
            case 'm': usage(stderr,argv);break;
        }
    }
}

/*****************************************************************/
/********************    PGM PRINCIPAL   *************************/
/*****************************************************************/

int main(int argc,char **argv)
{
    // declaration des parametres d'entree
    //=========================================
    int largeur;		// largeur de l'image cree
    int hauteur;		// hauteur de l'image cree
    int ordre;		// ordre de la loi gamma
    double Imoyco=0.;		// intensité moyenne de la lumière simulée
    double DOP=-1.;            // valeur VRAIE du degré de polarisation de la lumière
    int init;		// initialisation de graine aleatoire
    int reals=0;            // nombre de réalisations de tirages MonteCarlo
    
    /* Declare variables images*/
    //=========================================
    double **image_X, **image_Y, **i_totale, **i_totale_poisson, ** buf1;
    
    // Declare variable estimation:
    char *nom_fich[0];
    int k=0;
    double *tab_moy, *tab_var ,*tab_moy_poi, *tab_var_poi;
    double *tab_beta1, *tab_beta2, *tab_beta1_poi, *tab_beta2_poi, *tab_beta1prim_poi, *tab_beta2prim_poi;
    double moy, variance,moy_poi,variance_poi;
    
    struct timeb temps;     // pour la graine aleatoire
    
    // Recuperation des parametres d'entree
    //=========================================
    
    Verif_entrees(argc,argv,nom_fich,&ordre,&Imoyco,&DOP,&hauteur,&largeur,&reals,&init);
    
    // Quelques vérifications
    if (Imoyco==0) { fprintf(stderr," Erreur: intensité moyenne non définie\n "); exit(0);}
    if (DOP< 0) {fprintf(stderr," Erreur: DOP de la lumière non défini\n"); exit(0);}
    if (reals==0) {fprintf(stderr," Nombre de réalisations non sélectionné: par défaut R= 5000 \n"); reals=5000;}
    
    fprintf(stderr,"\n Ordre de la loi gamma marginale   %d",ordre);
    fprintf(stderr,"\n Intensité Moyenne %f",Imoyco);
    fprintf(stderr,"\n Degré de polarisation de la lumière simulée %f",DOP);
    fprintf(stderr,"\n ==============================================");
    fprintf(stderr,"\n Taille de l'échantillon %d x %d = %d pixels",hauteur, largeur,hauteur* largeur);
    fprintf(stderr,"\n Nombre de réalisations %d",reals);
    fprintf(stderr,"\n initialisation de la graine %d\n",init);
    
    
    
    // Allocation des images nécessaires
    image_X		= (double **) d_alloue_2d(hauteur,largeur);
    image_Y		= (double **) d_alloue_2d(hauteur,largeur);
    i_totale	= (double **) d_alloue_2d(hauteur,largeur);
    i_totale_poisson= (double **) d_alloue_2d(hauteur,largeur);
    buf1		= (double **) d_alloue_2d(hauteur,largeur);
    
    //Allocation des  tableaux de  sortie
    tab_moy= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_var= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_moy_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_var_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    
    tab_beta1= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_beta2= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_beta1_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_beta2_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_beta1prim_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    tab_beta2prim_poi= (double*) calloc( (unsigned) reals, sizeof(double));
    
    
    // Initialisation du generateur aleatoire
    //=========================================
    if(init==1)
    {
        time(&(temps.time));
        srand48(temps.time);
    }
    
    for (k=0; k<reals; k++)   // Début de la boucle de Monte carlo
    {
        
        bruit_gamma_d( (1+DOP)*Imoyco/2,ordre,hauteur,largeur, buf1, image_X );
        bruit_gamma_d( (1-DOP)*Imoyco/2,ordre,hauteur,largeur, buf1, image_Y );
        
        d_addmat(hauteur, largeur, i_totale, image_X, image_Y);                // creation de l'image d'intensité
        
        if (Imoyco <= 10)
        {
            poisson_direct_d(1, i_totale,hauteur,largeur, i_totale_poisson);            // Poissonisation de l'intensité
        }
        else
        {
            poisson_rejection_d(1, i_totale,hauteur,largeur, i_totale_poisson);
        }
        
        
        stat_image( i_totale, &variance, & moy, hauteur, largeur);              // Calcul des moyenne et variance
        stat_image( i_totale_poisson, &variance_poi, & moy_poi, hauteur, largeur);  // des images de taille N
        
        tab_moy[k]= moy;                       // Enregistrement dans tableaux
        tab_var[k]= variance;
        tab_moy_poi[k]=moy_poi;
        tab_var_poi[k]=variance_poi;
        
        tab_beta1[k]= 2*ordre*variance/(Imoyco*Imoyco) - 1 ;                          // Calcul des estimateurs ;
        tab_beta2[k]= 2*ordre*variance/(moy*moy) - 1 ;
        tab_beta1_poi[k]= 2*ordre*variance_poi/(Imoyco*Imoyco) - 1 ;
        tab_beta2_poi[k]= 2*ordre*variance_poi/(moy_poi*moy_poi) - 1 ;
        tab_beta1prim_poi[k]= 2*ordre*variance_poi/(Imoyco*Imoyco) - 2/Imoyco - 1 ;
        tab_beta2prim_poi[k]= 2*ordre*variance_poi/(moy_poi*moy_poi) - 2/moy_poi - 1 ;
        
        
    } /* Fin de la boucle Monte-Carlo */
    
    // SAUVEGARDE DES DONNEES PAR REALISATION
    if (nom_fich[0] != NULL)
    {
        fprintf(stderr,"\n \n Moyenne et variance des images d'intensité (poissonisée ou non) \n");
        fprintf(stderr,"sont sauvegardées dans le fichier %s \n",nom_fich[0]);
        saveVec2oct(  tab_moy, reals ,"moy_Itot",nom_fich[0],1);
        saveVec2oct(  tab_var, reals ,"var_Itot",nom_fich[0],0);
        saveVec2oct(  tab_moy_poi, reals ,"moy_Itot_poi",nom_fich[0],0);
        saveVec2oct(  tab_var_poi, reals ,"var_Itot_poi",nom_fich[0],0);
    }
    
    
    fprintf(stderr,"%f",bar_err_est(tab_beta1,floor(sqrt(reals))));
    fprintf(stderr,"%f",bar_err_var(tab_beta1,floor(sqrt(reals))));
    
    // DETERMINATION DES STATS DES ESTIMATEURS ET AFFICHAGE DU RESULTAT :
    fprintf(stdout," \n=====================================================================\n");
    fprintf(stdout,"                              RESULTATS\n");
    fprintf(stdout," =====================================================================\n");
    fprintf(stdout," ESTIMATION DU DOP A PARTIR D'UNE ! IMAGE:\n");
    fprintf(stdout," Taille echantillon N= %d - R= %d realisations \n",hauteur*largeur,reals);
    fprintf(stdout," BETA VRAI= (DOP VRAI)^2 = %f - INTENSITE MOYENNE THEORIQUE= %f \n",DOP*DOP,Imoyco);
    fprintf(stdout," =====================================================================\n\n ");
    fprintf(stdout," BRUIT DE SPECKLE ( CORRESPONDANT A UN SPECKLE D'ORDRE %d )\n",ordre);
    fprintf(stdout," =====================================================================\n ");
    moy=d_moyenne(reals,tab_beta1);
    fprintf(stdout," Estimateur Beta 1          : moyenne %f   - variance %f  \n ",moy,d_variance(reals,tab_beta1,moy));
    fprintf(stdout,"            Barre Erreur +/-:         %f   -          %f     \n",bar_err_est(tab_beta1,floor(sqrt(reals))),bar_err_var(tab_beta1,floor(sqrt(reals))));
    moy=d_moyenne(reals,tab_beta2);
    fprintf(stdout," Estimateur Beta 2         : moyenne %f   - variance %f  \n ",moy,d_variance(reals,tab_beta2,moy));
    fprintf(stdout,"           Barre Erreur +/-:       %f   -    %f     \n\n",bar_err_est(tab_beta2,floor(sqrt(reals))),bar_err_var(tab_beta2,floor(sqrt(reals))));
    fprintf(stdout," BRUIT DE SPECKLE + POISSON ( CORRESPONDANT A UN SPECKLE D'ORDRE %d )\n",ordre);
    fprintf(stdout," =====================================================================\n ");
    moy=d_moyenne(reals,tab_beta1_poi);
    fprintf(stdout," Estimateur Beta 1         : moyenne %f   - variance %f  \n ",moy,d_variance(reals,tab_beta1_poi,moy));
    fprintf(stdout,"           Barre Erreur +/-:       %f   -    %f     \n",bar_err_est(tab_beta1_poi,floor(sqrt(reals))),bar_err_var(tab_beta1_poi,floor(sqrt(reals))));
    moy=d_moyenne(reals,tab_beta2_poi);
    fprintf(stdout," Estimateur Beta 2         : moyenne %f   - variance %f  \n ",moy,d_variance(reals,tab_beta2_poi,moy));
    fprintf(stdout,"           Barre Erreur +/-:       %f   -    %f     \n",bar_err_est(tab_beta2_poi,floor(sqrt(reals))),bar_err_var(tab_beta2_poi,floor(sqrt(reals))));
    moy=d_moyenne(reals,tab_beta1prim_poi);
    fprintf(stdout," Estimateur Beta 1 modifié : moyenne %f   - variance %f  \n "
            ,moy,d_variance(reals,tab_beta1prim_poi,moy));
    fprintf(stdout,"           Barre Erreur +/-:       %f   -    %f     \n",bar_err_est(tab_beta1prim_poi,floor(sqrt(reals))),bar_err_var(tab_beta1prim_poi,floor(sqrt(reals))));
    moy=d_moyenne(reals,tab_beta2prim_poi);
    fprintf(stdout," Estimateur Beta 2 modifié : moyenne %f   - variance %f  \n "
            ,moy,d_variance(reals,tab_beta2prim_poi,moy));
    fprintf(stdout,"           Barre Erreur +/-:       %f   -    %f     \n",bar_err_est(tab_beta2prim_poi,floor(sqrt(reals))),bar_err_var(tab_beta2prim_poi,floor(sqrt(reals))));
    
    
    
    
    
    // Liberation place memoire
    //========================================
    d_efface_2d(hauteur,largeur,image_X);	// image generee
    d_efface_2d(hauteur,largeur,image_Y);	// image generee
    d_efface_2d(hauteur,largeur,i_totale);	// image generee
    d_efface_2d(hauteur,largeur,i_totale_poisson);	// image generee
    d_efface_2d(hauteur,largeur,buf1);	// tampon
    
    free(tab_moy);
    free(tab_var);
    free(tab_moy_poi);
    free(tab_var_poi);
    
    free(tab_beta1);
    free(tab_beta2);
    free(tab_beta1_poi);  
    free(tab_beta2_poi); 
    free(tab_beta1prim_poi);
    free(tab_beta2prim_poi);
    
    return(0);
}

