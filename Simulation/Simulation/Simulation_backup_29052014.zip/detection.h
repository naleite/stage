//
//  detection.h
//  Simulation
//
//  Created by NALEITE on 14-5-20.
//
//

#ifndef Simulation_detection_h
#define Simulation_detection_h


#endif

extern void calcul_histo(double *vecteur, int size, double min, double max, int pt_nb_bin, double *histo);

extern void calcul_Pd_Pfa(int nb_niv, double *tab_P, double *tab_Q, int nb_pts);

extern void histo_zones(double *crit, int nb_niv,double dx,double n_min, int reals,
						double *hist_abs, double *hist_val_cible, double *hist_val_fond);

extern void calcule_critere_GLRT(int  taille, int reals, double **champ, int taille_cible, double *critere, int flag_cible);

extern void calcule_critere_LRTpoi(int  taille, int reals, double **champ, int taille_cible, double *critere, int flag_cible,
								   double moy_cible, double moy_fond);


extern void genere_echantillons_detection(int taille, int reals, double **champ,  int taille_cible, int  N_cible, double Fano_init, double Fano_fond);


