# include <stdio.h>
# include <time.h>
# include <math.h>
# include <stdlib.h>
# include <getopt.h>

# include "utils_tous.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->progressBar->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::simu(){
         int Nw=ui->spinBox_Nw->value();
         int Nw_=ui->spinBox_Nw_->value();

         int ordre=ui->slider_ordre->value();
         int reals=ui->spinBox_reals->value();

        //arguments de H1
        double h1_Imoyco_w=ui->doubleSpinBox_Imoy_w->value();
        double h1_Imoyco_w_=ui->doubleSpinBox_Imoy_w_->value();
        double h1_DOP_w=ui->doubleSpinBox_DOP_w->value();
        double h1_DOP_w_=ui->doubleSpinBox_DOP_w_->value();

        //arguments de H0
            double h0_Imoyco_w_=h1_Imoyco_w_;
            double h0_Imoyco_w =h0_Imoyco_w_;
            double h0_DOP_w_=h1_DOP_w_;
            double h0_DOP_w =h0_DOP_w_;

        ui->progressBar->setValue(10);
            //================GENERATIONS ET TESTS POUR H0==================//
            double **h0_tab_X=d_alloue_2d(reals, Nw+Nw_);
            double **h0_tab_Y=d_alloue_2d(reals, Nw+Nw_);
            double **h0_tab_tot=d_alloue_2d(reals, Nw+Nw_);
            double **h0_tab_ICEO=d_alloue_2d(reals, Nw+Nw_);
            double **h0_tab_delta=d_alloue_2d(reals, Nw+Nw_);
    ui->progressBar->setValue(15);
            //Generer des images // et |_ (X ET Y) pour w et w_ de H0;
            generer_image_XY(Nw, h0_Imoyco_w, h0_DOP_w, Nw_, h0_Imoyco_w_, h0_DOP_w_, ordre, reals, h0_tab_X, h0_tab_Y);

            //generer Itot, p et delta de image en fonction de Image_X et Image_Y
            generer_3image(Nw+Nw_, reals, h0_tab_X, h0_tab_Y, h0_tab_tot, h0_tab_ICEO, h0_tab_delta);
ui->progressBar->setValue(25);
            //Test de detection
            double *h0_test_itot;//Test de dectection de Itot pour H0
            double *h0_test_delta;//Test de dectection de delta pour H0
            double *h0_test_LRTp;
            double *h0_test_GLRTp;
            double *h0_test_LRT_s;
            double *h0_test_GLRT_s;


            h0_test_itot=test_tot(reals, Nw, Nw_, h0_tab_tot); //test1 de detection pour Itot
ui->progressBar->setValue(30);
            h0_test_delta=test_delta(reals, Nw, Nw_, h0_tab_delta); //test2 de detection pour Delta
            ui->progressBar->setValue(35);
            //Test de LRT p
            h0_test_LRTp=test_LRT(h0_DOP_w_, h1_DOP_w_, h1_DOP_w, reals, Nw, Nw_, h0_tab_ICEO);
            ui->progressBar->setValue(40);
            //Test de GLRT p
            h0_test_GLRTp=test_GLRT(reals, Nw, Nw_, h0_tab_ICEO);
            ui->progressBar->setValue(45);
            //Test de LRT_s
            h0_test_LRT_s=test_LRT_s(h1_Imoyco_w, h0_Imoyco_w_, h1_DOP_w, h0_DOP_w_, reals, Nw,Nw_,h0_tab_tot);
            ui->progressBar->setValue(50);
            //Test de GLRT_S
            h0_test_GLRT_s=test_GLRT_s(reals, Nw, Nw_, h0_tab_tot);
            ui->progressBar->setValue(55);
            //================GENERATIONS ET TESTS POUR H1==================//

            double **h1_tab_X=d_alloue_2d(reals, Nw+Nw_);//Generation de image//
            double **h1_tab_Y=d_alloue_2d(reals, Nw+Nw_);

            double **h1_tab_tot=d_alloue_2d(reals, Nw+Nw_);//tot
            double **h1_tab_ICEO=d_alloue_2d(reals, Nw+Nw_);//ICEO
            double **h1_tab_delta=d_alloue_2d(reals, Nw+Nw_);//Delta

            //Generer des images // et |_ (X ET Y) pour w et w_ de H1;
            generer_image_XY(Nw, h1_Imoyco_w, h1_DOP_w, Nw_, h1_Imoyco_w_, h1_DOP_w_, ordre, reals, h1_tab_X, h1_tab_Y);

            //generer Itot, ICEO et Delta de image en fonction de Image_X et Image_Y
            generer_3image(Nw+Nw_, reals, h1_tab_X, h1_tab_Y, h1_tab_tot, h1_tab_ICEO, h1_tab_delta);

            //Test de detection
            double *h1_test_itot;//Test de dectection de Itot pour H1
            double *h1_test_delta;//Test de dectection de delta pour H1
            double *h1_test_LRTp;
            double *h1_test_GLRTp;
            double *h1_test_LRT_s;
            double *h1_test_GLRT_s;


            h1_test_itot=test_tot(reals, Nw, Nw_, h1_tab_tot);
            h1_test_delta=test_delta(reals, Nw, Nw_, h1_tab_delta);
            //Test de LRT p
            h1_test_LRTp=test_LRT(h0_DOP_w_, h1_DOP_w_, h1_DOP_w, reals, Nw, Nw_, h1_tab_ICEO);
            //Test de GLRT p
            h1_test_GLRTp=test_GLRT(reals, Nw, Nw_, h1_tab_ICEO);

            h1_test_LRT_s=test_LRT_s(h1_Imoyco_w, h0_Imoyco_w_, h1_DOP_w, h0_DOP_w_, reals, Nw,Nw_,h1_tab_tot);

            h1_test_GLRT_s=test_GLRT_s(reals, Nw, Nw_, h1_tab_tot);
            ui->progressBar->setValue(70);
            //Calcul de courbe COR pour chaque test
               // printf("COR_TOT:\n");
                generer_COR(h0_test_itot, h1_test_itot, reals,"Cor_tot.dat");
                ui->progressBar->setValue(75);
                //printf("COR_delta:\n");
                generer_COR(h0_test_delta, h1_test_delta, reals,"Cor_delta.dat");
                ui->progressBar->setValue(80);
               // printf("COR_LRTp:\n");
                generer_COR(h0_test_LRTp, h1_test_LRTp, reals,"Cor_LRTp.dat");
                ui->progressBar->setValue(85);
                //printf("COR_GLRTp:\n");
                generer_COR(h0_test_GLRTp, h1_test_GLRTp, reals,"Cor_GLRTp.dat");
                //printf("COR_LRTs:\n");
                ui->progressBar->setValue(90);
                generer_COR(h0_test_LRT_s, h1_test_LRT_s, reals, "Cor_LRTs.dat");
                //printf("COR_GLRTs:\n");
                ui->progressBar->setValue(95);
                generer_COR(h0_test_GLRT_s, h1_test_GLRT_s, reals, "Cor_GLRTs.dat");

                ui->progressBar->setValue(98);
  //              char buffer[100];
  //              getcwd(buffer, sizeof(buffer));
  //              printf("Generation COR reussit.\nLes donnees sont sauvegardees sous \n%s avec l'extension \".dat\" \n ",buffer);
            //	for (int i=0; i<reals; i++) {
            //		printf("h0_GLRTs[%d]: %f \n",i,h0_test_GLRT_s[i]);
            //	}
            //
            //	for (int i=0; i<reals; i++) {
            //		printf("h1_GLRTs[%d]: %f \n",i,h1_test_GLRT_s[i]);
            //	}



                //printf("test log 10=%f\n",log(10));

                //Afficher des resultat de LRT p
            //	printf("exp2=%f \n",exp(2));
            //	printf("exp2=%f \n",exp2(2));
            //	printf("log2=%f \n",log(-2));

                //============Des nettoyage=========================
                d_efface_2d(reals, Nw+Nw_, h0_tab_X);
                d_efface_2d(reals, Nw+Nw_, h0_tab_Y);
                d_efface_2d(reals, Nw+Nw_, h0_tab_tot);
                d_efface_2d(reals, Nw+Nw_, h0_tab_ICEO);
                d_efface_2d(reals, Nw+Nw_, h0_tab_delta);

                d_efface_2d(reals, Nw+Nw_, h1_tab_X);
                d_efface_2d(reals, Nw+Nw_, h1_tab_Y);
                d_efface_2d(reals, Nw+Nw_, h1_tab_tot);
                d_efface_2d(reals, Nw+Nw_, h1_tab_ICEO);
                d_efface_2d(reals, Nw+Nw_, h1_tab_delta);

                free(h0_test_delta);
                free(h0_test_itot);
                free(h0_test_LRTp);
                free(h0_test_GLRTp);
                free(h0_test_GLRT_s);
                free(h0_test_LRT_s);

                free(h1_test_delta);
                free(h1_test_itot);
                free(h1_test_LRTp);
                free(h1_test_GLRTp);
                free(h1_test_GLRT_s);
                free(h1_test_LRT_s);
                ui->progressBar->setValue(99);
}

void MainWindow::on_pushButton_clicked()
{


   // QMessageBox::information(NULL,"Info","Demarrage de la simulation! ","OK",NULL);
    ui->progressBar->setVisible(true);
    simu();
    ui->progressBar->setValue(100);
QMessageBox::information(NULL,"Info","La simulation se termine.","OK",NULL);
}

void MainWindow::on_actionExit_triggered()
{
    exit(0);
}
